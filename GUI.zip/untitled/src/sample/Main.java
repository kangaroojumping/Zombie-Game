package sample;

import javafx.application.Application;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import pngs.menu;
import sample.pngs.files.SubSceneText;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main extends Application {
    private AnchorPane  root;
    private GameSubscene sceneToHide;
    private GameSubscene playSubScene;
    private GameSubscene scoresSubScene;
    private GameSubscene helpSubScene;
    private GameSubscene historySubScene;
    List <CharacterPicker>characterList;
    private Character chosenCharacter;
    MediaPlayer BGM;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        int x = 25;
        root = new AnchorPane(); // must have

        primaryStage.setScene(new Scene(root, 1100, 700));
        primaryStage.show();
        //backGroundMusic();
        background();
        logo();

        menu play = new menu("P l A Y");
        play.getPane().setTranslateX(x);
        play.getPane().setTranslateY(4*x);
        root.getChildren().add(play.getPane());
        createCharacterSubScene();
        play.getButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                showSubScene(playSubScene);
            }
        });

        menu scores = new menu("S C O R E S");
        scores.getPane().setTranslateX(x);
        scores.getPane().setTranslateY(8*x);
        root.getChildren().add(scores.getPane());
        scoresSubScene = new GameSubscene();
        root.getChildren().add(scoresSubScene);
        scores.getButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                showSubScene(scoresSubScene);
            }
        });

        menu help = new menu("I N S T R U C T I O N");
        help.getPane().setTranslateX(x);
        help.getPane().setTranslateY(12*x);
        root.getChildren().add(help.getPane());
        createInstructionSubScene();
        help.getButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                showSubScene(helpSubScene);
            }
        });

        menu history = new menu("H I S T O R Y");
        history.getPane().setTranslateX(x);
        history.getPane().setTranslateY(16*x);
        root.getChildren().add(history.getPane());
        createHistorySubScene();
        history.getButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event)
            {
                showSubScene(historySubScene);
            }
        });

        menu exit = new menu("E X I T");
        exit.getPane().setTranslateX(x);
        exit.getPane().setTranslateY(20*x);
        root.getChildren().add(exit.getPane());
        exit.getButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                primaryStage.close();
            }
        });

    }

    private void createInstructionSubScene() throws IOException {
        helpSubScene = new GameSubscene();
        root.getChildren().add(helpSubScene);
        SubSceneLabel InstructionCharacterLabel = new SubSceneLabel("I N S T R U C T I O N",150,25); // title
        SubSceneText InstructionText = new SubSceneText("This is the example of Instruction text ", 30,50); // for text in SubScene
        helpSubScene.getPane().getChildren().add( InstructionCharacterLabel);
        helpSubScene.getPane().getChildren().add(InstructionText);
    }

    private void createHistorySubScene() throws IOException {
        historySubScene = new GameSubscene();
        root.getChildren().add(historySubScene);
        SubSceneLabel historyCharacterLabel = new SubSceneLabel("History",200,25);
        historySubScene.getPane().getChildren().add( historyCharacterLabel);
    }

    private void createCharacterSubScene() throws IOException {
        playSubScene = new GameSubscene();
        root.getChildren().add(playSubScene); // 8.22
        SubSceneLabel choseCharacterLabel = new SubSceneLabel("Chose your Character",110,25);
        playSubScene.getPane().getChildren().add(choseCharacterLabel);
        playSubScene.getPane().getChildren().add(crateCharacterChose());

        menu start = new menu("S T A R T ");
        start.getPane().setTranslateX(380);
        start.getPane().setTranslateY(260);
        playSubScene.getPane().getChildren().add(start.getPane());
        start.getButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // THE GAME CODE IS HERE!!
            }
        });
    }
    private HBox crateCharacterChose(){
        HBox box = new HBox();
        box.setSpacing(20);
        characterList = new ArrayList<>(); // I copy these codes. think means the list from the Character
        for(Character character : Character.values()){
            CharacterPicker characterToPick = new CharacterPicker(character);
            characterList.add(characterToPick);
            box.getChildren().add(characterToPick);
            characterToPick.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    for(CharacterPicker character : characterList){
                        character.setIsCircleChosen(false);
                    }
                    characterToPick.setIsCircleChosen(true);
                    chosenCharacter = characterToPick.getCharacter();
                }
            });
        }
        box.setLayoutX(200); // for inside the subScene
        box.setLayoutY(100);
        box.setSpacing(100);
        return box;
    }

    public void background(){
        Image backgroundImage = new Image("sample/pngs/files/73d4f317117cf08d5967b1ba2baa0eea.jpg",1100,700,false,true);
        BackgroundImage backgroundImageset = new BackgroundImage(backgroundImage,BackgroundRepeat.ROUND,BackgroundRepeat.ROUND, BackgroundPosition.CENTER,null);
        root.setBackground(new Background(backgroundImageset));
    }
    public void logo(){
        ImageView logo = new ImageView("sample/pngs/files/zombie-logo-png-1.png");
        logo.setLayoutX(500);
        logo.setLayoutY(25);
        logo.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) { // setting for mouse entire the pic
                logo.setEffect(new DropShadow());
            }
        });
        logo.setOnMouseExited(new EventHandler<MouseEvent>() { //setting for mouse exit the pic
            @Override
            public void handle(MouseEvent event) {
                logo.setEffect(null);
            }
        });
        root.getChildren().add(logo);
    }

    private void showSubScene (GameSubscene subScene ){ // moving Scene in and out.
        if(sceneToHide != null){
            sceneToHide.moveSubScene();
        }
        subScene.moveSubScene();
        sceneToHide = subScene;

    }
    public void backGroundMusic(){

        String music = "BGM.mp3"; // the file must locate at the root , so don't change the file location.
        Media h = new Media(Paths.get(music).toUri().toString());
        BGM = new MediaPlayer(h);
        BGM.play();
    }
}