package sample;

import javafx.geometry.Pos;
import javafx.scene.layout.VBox;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class CharacterPicker extends VBox {
    private ImageView circleImage;
    private ImageView characterImage;

    private String circleNotChosen = "sample/pngs/files/micro8icons-95-512.png";
    private String circleChosen ="sample/pngs/files/micro8icons-94-512.png";
    private Character character;
    private boolean isCircleChosen;

    public CharacterPicker(Character character){
        circleImage = new ImageView(circleNotChosen);
        characterImage = new ImageView(character.getUrl());
        this.character = character;
        isCircleChosen =false;
        this.setAlignment(Pos.CENTER); // right above the character
        this.setSpacing(20);
        circleImage.setFitHeight(50);
        circleImage.setFitWidth(50);
        characterImage.setFitHeight(150);
        characterImage.setFitWidth(150);
        this.getChildren().add(circleImage);
        this.getChildren().add(characterImage);
    }

    public Character getCharacter(){
        return character;
    }

    public boolean getIsCircleChosen(){
        return isCircleChosen;
    }

    public void setIsCircleChosen(boolean isCircleChosen){
        this.isCircleChosen = isCircleChosen;
        String imageToSet = this.isCircleChosen ? circleChosen : circleChosen;
        circleImage.setImage(new Image((imageToSet)));
    }
}
