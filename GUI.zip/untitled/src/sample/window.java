package sample;

public class window {
}
