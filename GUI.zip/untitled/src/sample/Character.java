package sample;

public enum Character {
    Character1("sample/pngs/files/e8e86cb0dc46795dc87f0d306004c989.png");

    private String urlCharacter;

    private  Character(String urlCharacter){
        this.urlCharacter = urlCharacter;
    }
    public String getUrl(){
        return this.urlCharacter;
    }
}
